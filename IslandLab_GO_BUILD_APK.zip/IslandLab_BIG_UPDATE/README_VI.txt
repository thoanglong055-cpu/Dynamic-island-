ISLAND LAB — ANDROID PROJECT (SOURCE)
====================================

Mục tiêu
- Overlay dạng Dynamic Island trên Android.
- Kéo thả vị trí, chạm để bung/thu gọn.
- Chỉnh chiều rộng, chiều cao, độ cong superellipse (squircle), vị trí ngang/dọc.
- Đọc nội dung thông báo qua NotificationListenerService.
- Lấy icon ứng dụng từ PackageManager.
- Lấy ảnh album / metadata khi ứng dụng phát nhạc gửi MediaStyle notification hoặc MediaSession metadata.
- Chạm thẻ để mở PendingIntent của thông báo gốc khi có.

QUAN TRỌNG
Đây là MÃ NGUỒN, chưa phải APK. Bản build chưa được kiểm thử trên thiết bị thật.
Môi trường tạo file hiện tại không có Android SDK, Gradle và không có kết nối tải bộ công cụ,
nên không thể biên dịch APK tại đây. Không có APK giả/placeholder trong ZIP.

CÁCH BUILD TRÊN ĐIỆN THOẠI
1. Cài AndroidIDE từ nguồn chính thức của dự án.
2. Giải nén ZIP vào bộ nhớ máy.
3. Mở thư mục IslandLab_BIG_UPDATE bằng AndroidIDE (chọn thư mục có settings.gradle).
4. Chờ Gradle Sync tải plugin Android Gradle Plugin 8.6.1 và các thành phần cần thiết.
5. Chọn app > assembleDebug / Build APK.
6. APK debug nếu build thành công nằm tại:
   app/build/outputs/apk/debug/app-debug.apk
7. Cài APK, mở Island Lab và cấp:
   - quyền hiển thị trên ứng dụng khác (Overlay)
   - quyền truy cập thông báo (Notification access)
   - quyền thông báo nếu Android yêu cầu.
8. Bấm BẬT ISLAND OVERLAY.

YÊU CẦU BUILD
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.6.1
- Gradle 8.7 hoặc bản tương thích được AndroidIDE đề xuất

GIỚI HẠN HIỆN TẠI
- Chưa có điều khiển media play/pause/next/previous.
- Chưa có trạng thái cuộc gọi, chỉ đường, hẹn giờ, pin sạc hoặc hoạt động live chuyên biệt.
- Không chạy Apple ActivityKit trên Android; các tính năng tương tự phải tích hợp bằng API Android riêng.
- Ảnh album và icon được lấy từ ứng dụng trên máy, không nhúng hình ảnh Apple có bản quyền.
- Khả năng đọc metadata phụ thuộc từng ứng dụng phát nhạc và quyền hệ thống.

BUILD APK TRÊN ĐÁM MÂY:
Gói ZIP đã có .github/workflows/build-apk.yml. Xem BUILD_APK_ON_PHONE_VI.txt
để đưa mã nguồn lên GitHub và tải APK từ mục Actions > Artifacts.
