#!/usr/bin/env bash
set -e
./gradlew :app:assembleDebug
mkdir -p APK
cp app/build/outputs/apk/debug/app-debug.apk APK/IslandLab-debug.apk
zip -r IslandLab_with_APK.zip . -x ".gradle/*" "*/build/intermediates/*" "*/build/tmp/*"
echo "Created IslandLab_with_APK.zip containing APK/IslandLab-debug.apk"
