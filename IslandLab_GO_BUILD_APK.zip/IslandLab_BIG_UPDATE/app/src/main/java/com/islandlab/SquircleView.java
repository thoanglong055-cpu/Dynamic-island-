package com.islandlab;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Superellipse path (n=4) for a softer Squircle-like outline. */
public class SquircleView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path=new Path();
    private int fill=Color.BLACK;
    private float exponent=4f;
    public SquircleView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setFill(int color){fill=color;invalidate();}
    public void setExponent(float n){exponent=Math.max(2f,Math.min(8f,n));invalidate();}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);float w=getWidth(),h=getHeight();if(w<=0||h<=0)return;
        path.reset();float rx=w/2f,ry=h/2f,cx=rx,cy=ry;
        int steps=120;
        for(int i=0;i<=steps;i++){
            double a=2*Math.PI*i/steps;
            double ca=Math.cos(a),sa=Math.sin(a);
            float x=(float)(cx+rx*Math.signum(ca)*Math.pow(Math.abs(ca),2.0/exponent));
            float y=(float)(cy+ry*Math.signum(sa)*Math.pow(Math.abs(sa),2.0/exponent));
            if(i==0)path.moveTo(x,y);else path.lineTo(x,y);
        }
        path.close();paint.setColor(fill);paint.setStyle(Paint.Style.FILL);c.drawPath(path,paint);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1f);paint.setColor(0x30ffffff);c.drawPath(path,paint);
    }
}
