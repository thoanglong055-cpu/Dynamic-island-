package com.islandlab;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.provider.Settings;
import android.media.session.*;
import android.media.MediaMetadata;
import android.media.session.PlaybackState;

public class IslandOverlayService extends Service {
    WindowManager wm; FrameLayout island; WindowManager.LayoutParams lp;
    android.content.SharedPreferences prefs;
    String title="",body="",pkg="",activeKey="";
    Bitmap artwork; PendingIntent openIntent;
    MediaController mediaController;
    boolean expanded=false;
    String channel="island_foreground";
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);prefs=getSharedPreferences("island",MODE_PRIVATE);createChannel();}
    @Override public int onStartCommand(Intent in,int flags,int id){
        String action=in==null?"START":in.getAction();
        // A foreground service must promote itself immediately, including when
        // it was started by NotificationListenerService for a notification update.
        if(!Settings.canDrawOverlays(this)){
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(101,makeNotification());
        if("NOTIFICATION".equals(action)&&in!=null){
            readNotification(in);
            if(island==null)attach(); else render();
            return START_STICKY;
        }
        if("REMOVED".equals(action)&&in!=null){
            String removedKey=in.getStringExtra("key");
            if(removedKey!=null&&removedKey.equals(activeKey)){
                title="";body="";artwork=null;openIntent=null;activeKey="";
                if(island!=null)render();
            }
            return START_STICKY;
        }
        if(island==null)attach(); else if("UPDATE".equals(action))update();
        return START_STICKY;
    }
    void readNotification(Intent i){
        title=i.getStringExtra("title");body=i.getStringExtra("text");pkg=i.getStringExtra("package");activeKey=i.getStringExtra("key");
        if(Build.VERSION.SDK_INT>=33)artwork=i.getParcelableExtra("art",Bitmap.class);else artwork=(Bitmap)i.getParcelableExtra("art");
        if(Build.VERSION.SDK_INT>=33)openIntent=i.getParcelableExtra("openIntent",PendingIntent.class);else openIntent=(PendingIntent)i.getParcelableExtra("openIntent");
        MediaSession.Token token;
        if(Build.VERSION.SDK_INT>=33)token=i.getParcelableExtra("token",MediaSession.Token.class);else token=(MediaSession.Token)i.getParcelableExtra("token");
        if(token!=null)try{
            mediaController=new MediaController(this,token);
            MediaMetadata md=mediaController.getMetadata();
            if(md!=null){
                String t=md.getString(MediaMetadata.METADATA_KEY_TITLE);
                String a=md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                if(t!=null&&!t.isEmpty())title=t;
                if(a!=null&&!a.isEmpty())body=a;
                Bitmap b=md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if(b==null)b=md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if(b!=null)artwork=b;
            }
        }catch(Exception ignored){}
    }
    void attach(){
        int w=dp(prefs.getInt("width",164)),h=dp(prefs.getInt("height",40));
        int sw=getResources().getDisplayMetrics().widthPixels;
        int x=Math.max(0,Math.min(sw-w,(sw*prefs.getInt("x",50)/100)-w/2));
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        lp=new WindowManager.LayoutParams(w,h,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.LEFT;lp.x=x;lp.y=dp(prefs.getInt("y",18));
        island=new FrameLayout(this);island.setElevation(dp(14));
        island.setOnTouchListener(new View.OnTouchListener(){
            float sx,sy;int ox,oy;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=lp.x;oy=lp.y;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){lp.x=Math.max(0,ox+(int)(e.getRawX()-sx));lp.y=Math.max(0,oy+(int)(e.getRawY()-sy));wm.updateViewLayout(island,lp);return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){
                    float dx=Math.abs(e.getRawX()-sx),dy=Math.abs(e.getRawY()-sy);
                    if(dx<dp(9)&&dy<dp(9)){expanded=!expanded;render();}
                    int sw=getResources().getDisplayMetrics().widthPixels;
                    prefs.edit().putInt("x",Math.max(0,Math.min(100,(lp.x*100)/Math.max(1,sw)))).putInt("y",lp.y/(int)getResources().getDisplayMetrics().density).apply();
                    return true;
                }return true;
            }
        });
        render();try{wm.addView(island,lp);}catch(Exception e){island=null;stopSelf();}
    }
    void render(){
        if(island==null)return;
        island.removeAllViews();
        if(!expanded){
            lp.width=dp(prefs.getInt("width",164));lp.height=dp(prefs.getInt("height",40));
            SquircleView shape=new SquircleView(this);shape.setFill(Color.BLACK);shape.setExponent(prefs.getInt("squircle",4));
            island.addView(shape,new FrameLayout.LayoutParams(-1,-1));
            if(artwork!=null){
                ImageView icon=new ImageView(this);icon.setImageBitmap(artwork);icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
                FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(dp(25),dp(25),Gravity.RIGHT|Gravity.CENTER_VERTICAL);ip.rightMargin=dp(7);
                island.addView(icon,ip);
            }
        }else{
            lp.width=dp(Math.max(270,prefs.getInt("width",164)));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setPadding(dp(14),dp(13),dp(14),dp(13));
            GradientDrawable bg=new GradientDrawable();bg.setColor(0xf21b202b);bg.setCornerRadius(dp(27));bg.setStroke(dp(1),0x40ffffff);card.setBackground(bg);
            if(artwork!=null){
                ImageView art=new ImageView(this);art.setImageBitmap(artwork);art.setScaleType(ImageView.ScaleType.CENTER_CROP);
                GradientDrawable clip=new GradientDrawable();clip.setColor(Color.WHITE);clip.setCornerRadius(dp(12));art.setBackground(clip);art.setClipToOutline(true);
                LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(52),dp(52));ap.rightMargin=dp(12);card.addView(art,ap);
            }else if(!pkg.isEmpty()){
                try{
                    ImageView app=new ImageView(this);app.setImageDrawable(getPackageManager().getApplicationIcon(pkg));
                    LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(42),dp(42));ap.rightMargin=dp(12);card.addView(app,ap);
                }catch(Exception ignored){}
            }
            LinearLayout texts=new LinearLayout(this);texts.setOrientation(LinearLayout.VERTICAL);texts.setGravity(Gravity.CENTER_VERTICAL);
            TextView t=new TextView(this);t.setText(title.isEmpty()?"Island Lab":title);t.setTextColor(Color.WHITE);t.setTextSize(14);t.setTypeface(null,1);t.setMaxLines(1);
            TextView b=new TextView(this);b.setText(body.isEmpty()?"Đang chờ hoạt động…":body);b.setTextColor(0xffc3ccda);b.setTextSize(12);b.setMaxLines(2);
            texts.addView(t);texts.addView(b);card.addView(texts,new LinearLayout.LayoutParams(0,-2,1));
            if(openIntent!=null){card.setOnClickListener(v->{try{openIntent.send();}catch(Exception ignored){}});}
            island.addView(card,new FrameLayout.LayoutParams(-1,-2));
        }
        try{wm.updateViewLayout(island,lp);}catch(Exception ignored){}
    }
    void update(){
        if(island==null){attach();return;}
        int sw=getResources().getDisplayMetrics().widthPixels,w=dp(prefs.getInt("width",164));
        lp.x=Math.max(0,Math.min(sw-w,(sw*prefs.getInt("x",50)/100)-w/2));lp.y=dp(prefs.getInt("y",18));
        render();
    }
    void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(channel,"Island Lab service",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    Notification makeNotification(){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,channel):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Island Lab đang hoạt động").setContentText("Overlay đang hiển thị").setOngoing(true).build();}
    @Override public void onDestroy(){if(island!=null){try{wm.removeView(island);}catch(Exception ignored){}island=null;}if(Build.VERSION.SDK_INT>=24)stopForeground(STOP_FOREGROUND_REMOVE);else stopForeground(true);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
