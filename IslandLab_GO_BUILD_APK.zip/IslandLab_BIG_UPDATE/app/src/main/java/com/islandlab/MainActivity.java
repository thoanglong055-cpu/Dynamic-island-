package com.islandlab;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.provider.Settings;
import android.net.Uri;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    android.content.SharedPreferences prefs;
    LinearLayout root;
    int accent=0xffc7dcff;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); prefs=getSharedPreferences("island",MODE_PRIVATE);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},501);
        }
        getWindow().setStatusBarColor(0xff080c13); getWindow().setNavigationBarColor(0xff080c13);
        build();
    }
    TextView label(String s,int size,int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    void addButton(String s,Runnable r) {
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(0xfff5f7fb);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff253246));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(8); root.addView(b,lp);
        b.setOnClickListener(v->r.run());
    }
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    void build() {
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(22),dp(30),dp(22),dp(32));
        root.setBackgroundColor(0xff090e17); scroll.addView(root); setContentView(scroll);
        root.addView(label("ISLAND LAB  /  BIG UPDATE",12,0xff9ebfff));
        TextView h=label("Dynamic Island",30,Color.WHITE); h.setTypeface(null,1); root.addView(h);
        root.addView(label("Native overlay • media artwork • notification cards • Squircle",12,0xffaab6c8));
        View gap=new View(this); root.addView(gap,new LinearLayout.LayoutParams(1,dp(18)));
        addButton("① CẤP QUYỀN HIỂN THỊ TRÊN ỨNG DỤNG KHÁC",()->{
            if(!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
            else toast("Đã có quyền Overlay");
        });
        addButton("② CẤP QUYỀN ĐỌC THÔNG BÁO / MEDIA",()->startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        addButton("③ BẬT ISLAND OVERLAY",()->{
            if(!Settings.canDrawOverlays(this)){toast("Cấp quyền Overlay trước nhé");return;}
            Intent i=new Intent(this,IslandOverlayService.class); i.setAction("START");
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            toast("Đã gửi lệnh bật Island");
        });
        addButton("TẮT OVERLAY",()->stopService(new Intent(this,IslandOverlayService.class)));
        section("HÌNH DÁNG & VỊ TRÍ");
        slider("Chiều rộng","width",84,340,164," px");
        slider("Chiều cao","height",24,110,40," px");
        slider("Độ cong Squircle","squircle",2,8,4,"");
        slider("Vị trí ngang","x",0,100,50," %");
        slider("Vị trí dọc","y",0,650,18," px");
        section("HIỂN THỊ");
        root.addView(label("• Icon ứng dụng thật lấy từ PackageManager\n• Ảnh album thật lấy từ MediaStyle notification / MediaSession metadata\n• Nội dung thông báo thật qua NotificationListenerService\n• Mở app gốc khi chạm thẻ thông báo\n• Chạm viên thuốc để bung / thu gọn\n• Kéo thả vị trí trực tiếp\n• Squircle vẽ bằng superellipse Path, không dùng bo góc tròn thường\n• Dịch vụ foreground giữ overlay khi chuyển ứng dụng\n\nGiới hạn: quyền và khả năng đọc media tùy ứng dụng phát nhạc / phiên bản Android. Không thể chạy Apple ActivityKit trên Android; tính năng tương tự phải dựng bằng API Android.",13,0xffc0cad9));
    }
    void section(String s){TextView t=label(s,12,0xff9ebfff);t.setPadding(0,dp(24),0,dp(6));root.addView(t);}
    void slider(String name,String key,int min,int max,int def,String unit) {
        int val=prefs.getInt(key,def); TextView t=label(name+"   "+val+unit,14,Color.WHITE);t.setPadding(0,dp(13),0,0);root.addView(t);
        SeekBar sb=new SeekBar(this);sb.setMax(max-min);sb.setProgress(Math.max(0,Math.min(max-min,val-min)));
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean user){
                int n=p+min;t.setText(name+"   "+n+unit);prefs.edit().putInt(key,n).apply();
                Intent i=new Intent(MainActivity.this,IslandOverlayService.class);i.setAction("UPDATE");
                try{if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}catch(Exception ignored){}
            }
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        });root.addView(sb);
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
