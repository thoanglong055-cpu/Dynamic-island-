package com.islandlab;

import android.service.notification.*;
import android.app.Notification;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.session.MediaSession;
import android.media.session.MediaController;
import android.media.MediaMetadata;
import android.media.session.PlaybackState;
import android.content.ComponentName;

public class IslandNotificationListener extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        Notification n=sbn.getNotification(); if(n==null||n.extras==null)return;
        Bundle e=n.extras;
        String title=str(e.getCharSequence(Notification.EXTRA_TITLE));
        String text=str(e.getCharSequence(Notification.EXTRA_TEXT));
        String pkg=sbn.getPackageName();
        Bitmap art=null;
        try { art=e.getParcelable(Notification.EXTRA_LARGE_ICON,Bitmap.class); } catch(Exception ignored) {}
        if(art==null) try { art=e.getParcelable(Notification.EXTRA_PICTURE,Bitmap.class); } catch(Exception ignored) {}
        MediaSession.Token token=null;
        try { token=e.getParcelable(Notification.EXTRA_MEDIA_SESSION,MediaSession.Token.class); } catch(Exception ignored) {}
        Intent i=new Intent(this,IslandOverlayService.class);i.setAction("NOTIFICATION");
        i.putExtra("title",title);i.putExtra("text",text);i.putExtra("package",pkg);
        i.putExtra("art",art);i.putExtra("token",token);
        i.putExtra("key",sbn.getKey());
        if(n.contentIntent!=null)i.putExtra("openIntent",n.contentIntent);
        try{
            if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i);
            else startService(i);
        }catch(Exception ignored){}
    }
    @Override public void onNotificationRemoved(StatusBarNotification sbn) {
        Intent i=new Intent(this,IslandOverlayService.class);i.setAction("REMOVED");i.putExtra("key",sbn.getKey());
        try{
            if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i);
            else startService(i);
        }catch(Exception ignored){}
    }
    private String str(CharSequence s){return s==null?"":s.toString();}
}
